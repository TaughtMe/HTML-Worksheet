repo: TaughtMe/HTML-Worksheet
branch: main

## Last sync
date: 2026-10-26T21:46:48Z

### Updated in this project
- Planungsdokumente gelesen (README, PLAN, ARCHITEKTUR, BETRIEB)
- Noch keine UI im Repo – Mockups entstehen neu

## Screen map
| Screen | Repo files |
|---|---|
| iPad-App Mockups | docs/PLAN.md (Abschnitt 4), docs/ARCHITEKTUR.md |
